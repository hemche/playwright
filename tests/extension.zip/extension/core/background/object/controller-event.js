'use strict';

const ControllerReset = 'ControllerReset';

const SongNowPlaying = 'SongNowPlaying';

const SongUnrecognized = 'SongUnrecognized';

define(() => {
	return {
		ControllerReset,
		SongNowPlaying,
		SongUnrecognized,
	};
});
