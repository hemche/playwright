<!-- This file is generated automatically. Do not edit it manually. -->

# Web Scrobbler

## Third-party projects

-   [Bootstrap v4.6.2][bootstrap]
-   [FontAwesome v6.3.0][@fortawesome/fontawesome-free]
-   [jQuery v3.6.4][jquery]
-   [MD5 v2.19.0][blueimp-md5]
-   [MetadataFilter v1.1.1][metadata-filter]
-   [RequireJS v2.3.6][requirejs]
-   [WebextPolyfill v0.10.0][webextension-polyfill]

[bootstrap]: https://github.com/twbs/bootstrap/releases/download/v4.6.2/bootstrap-4.6.2-dist.zip
[@fortawesome/fontawesome-free]: https://use.fontawesome.com/releases/v6.3.0/fontawesome-free-6.3.0-web.zip
[jquery]: https://code.jquery.com/jquery-3.6.4.min.js
[blueimp-md5]: https://github.com/blueimp/JavaScript-MD5/archive/v2.19.0.zip
[metadata-filter]: https://github.com/web-scrobbler/metadata-filter/releases/download/v1.1.1/metadata-filter-1.1.1.tgz
[requirejs]: https://github.com/requirejs/requirejs/archive/2.3.6.zip
[webextension-polyfill]: https://unpkg.com/browse/webextension-polyfill@0.10.0/dist/
