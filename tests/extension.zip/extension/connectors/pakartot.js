'use strict';

Connector.playerSelector = '#player';

Connector.artistSelector = 'div.jp-player-artist > a';

Connector.trackSelector = 'div.jp-player-title > a';

Connector.playButtonSelector = '.jp-play';
