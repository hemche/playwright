'use strict';

Connector.playerSelector = '#player';

Connector.artistSelector = '#pl-info-text > h4';

Connector.trackSelector = '#pl-info-text > h3';

// Album title is only available when track is played through the album page
Connector.albumSelector = '.ad-info-text1 > h1';

Connector.playButtonSelector = '#pl-ctrl-play';

Connector.trackArtSelector = '.player-img > img';
