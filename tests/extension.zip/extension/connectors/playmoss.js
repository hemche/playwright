'use strict';

Connector.playerSelector = '#footer-player';

Connector.artistTrackSelector = '#footer-player li.playing a';

Connector.playButtonSelector = 'button.play';
