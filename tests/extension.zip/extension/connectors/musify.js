'use strict';

Connector.playerSelector = '.jp-controls';

Connector.artistTrackSelector = '.jp-title';

Connector.currentTimeSelector = '.jp-current-time';

Connector.durationSelector = '.jp-duration';

Connector.playButtonSelector = '.jp-play';
