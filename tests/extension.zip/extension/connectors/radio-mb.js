'use strict';

Connector.playerSelector = '#radiomb';

Connector.artistSelector = '#radiomb-np-artist';

Connector.trackSelector = '#radiomb-np-title';

Connector.trackArtSelector = '#radiomb-top';

Connector.isPlaying = () => $('#radiomb-play').hasClass('radiomb-playing');
