'use strict';

Connector.playerSelector = '.app-player';

Connector.artistSelector = '.mejs__track-author a';

Connector.trackSelector = '.mejs__track-title a';

Connector.currentTimeSelector = '.mejs__currenttime';

Connector.durationSelector = '.mejs__duration';

Connector.playButtonSelector = '.mejs__play';

Connector.trackArtSelector = '.mejs__track-artwork';
