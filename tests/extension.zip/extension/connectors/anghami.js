'use strict';

Connector.artistSelector = '.action-artist';

Connector.trackSelector = '.action-title';

Connector.playerSelector = '.player-wrapper';

Connector.trackArtSelector = '.track-coverart';

Connector.currentTimeSelector = '.main-player .duration-text:first-child';

Connector.durationSelector = '.main-player .duration-text:last-child';

Connector.playButtonSelector = '.player-controls .icon.play';
