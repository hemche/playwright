'use strict';

Connector.artistTrackSelector = '#programInformationText';
Connector.playerSelector = '#programInformationText';
