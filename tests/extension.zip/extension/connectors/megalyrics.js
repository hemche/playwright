'use strict';

Connector.playerSelector = '#player';

Connector.artistTrackSelector = '#pr_title';

Connector.timeInfoSelector = '#pr_time';

Connector.isPlaying = () => $('#pr_play').hasClass('playing');
