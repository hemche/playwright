'use strict';

Connector.playerSelector = '.now-playing-info';

Connector.artistSelector = '#artist_name';

Connector.trackSelector = '#song_name';

Connector.playButtonSelector = '#play';

Connector.trackArtSelector = '#cover.src';
