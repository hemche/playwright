'use strict';

Connector.playerSelector = '.radioplayer-localwrapper';

Connector.trackSelector = '.o-playlist__content .o-playlist__title';

Connector.artistSelector = '.o-playlist__content .o-playlist__artist';

Connector.trackArtSelector = '.o-playlist__image img';

Connector.playButtonSelector = 'button#play';

Connector.onReady = Connector.onStateChanged;
