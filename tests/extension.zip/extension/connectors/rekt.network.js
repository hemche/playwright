'use strict';

// A more specific selector simply wouldn't work
Connector.playerSelector = 'body';

Connector.artistTrackSelector = '#npTitle';

Connector.playButtonSelector = '#playerPlay';
