'use strict';

Connector.playButtonSelector = '.middle.paused';
Connector.playerSelector = '.inner-size';
Connector.trackSelector = '.current-track a:first';
Connector.artistSelector = '.current-track a:last';
Connector.currentTimeSelector = '.timer span:first';
Connector.durationSelector = '.timer span:last';
