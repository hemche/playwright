'use strict';

Connector.playerSelector = '.jp-audio';

Connector.artistSelector = '.playing > .artist';

Connector.trackSelector = '.playing > .title';

Connector.playButtonSelector = '.jp-play';

Connector.currentTimeSelector = '.jp-current-time';

Connector.durationSelector = '.jp-duration';
