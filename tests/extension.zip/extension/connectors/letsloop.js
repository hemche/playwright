'use strict';

Connector.playerSelector = '#player';

Connector.artistSelector = '#current-song-title .sub a';

Connector.trackSelector = '#current-song-title .main a';

Connector.trackArtSelector = '#player-image';
