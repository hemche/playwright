'use strict';

Connector.playerSelector = '.drawer-content';

Connector.isPlaying = () => $('.pulse-hover-play').hasClass('stop');

Connector.artistTrackSelector = '.pulse-info h3';
