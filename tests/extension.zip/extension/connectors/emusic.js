'use strict';

Connector.playerSelector = '.player';

Connector.artistSelector = '.track__meta-data a:first-child';

Connector.trackSelector = '.track__meta-data a:last-child';

Connector.playButtonSelector = '.player__play__button';

Connector.currentTimeSelector = '.track__time.float-left';

Connector.durationSelector = '.track__time.float-right';

Connector.trackArtSelector = '.player__album__cover .preloadImage';
