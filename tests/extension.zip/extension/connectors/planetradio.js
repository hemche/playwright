'use strict';

Connector.playerSelector = '.now-playing-wrapper';

Connector.artistSelector = '.text-right .title';

Connector.trackSelector = '.text-right .track';

Connector.trackArtSelector = '.now-playing-block.right .image';

Connector.playButtonSelector = '.play';
