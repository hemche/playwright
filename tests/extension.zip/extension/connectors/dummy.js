/**
 * I do nothing.
 *
 * I am here to be active on all websites, so once the users confirm
 * extension's permissions, they don't have to re-confirm on every update
 * that adds a new website connector.
 */
