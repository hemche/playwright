'use strict';

Connector.playerSelector = '.row.col-wrap';

Connector.artistSelector = '#labelartist';

Connector.trackSelector = '#labeltitle';

Connector.albumSelector = '#labelalbum';

Connector.trackArtSelector = '#artistimg';
