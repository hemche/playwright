'use strict';

Connector.playerSelector = '.now-play';

Connector.artistTrackSelector = '#current-track';

// Imago removes `stop` class of `.play-icon` element if a track is playing.
Connector.playButtonSelector = '.play-icon.stop';
