'use strict';

Connector.artistTrackSelector = '.progress > span';

Connector.playButtonSelector = 'a.play';

Connector.playerSelector = '.controls';
