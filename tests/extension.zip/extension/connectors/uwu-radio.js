'use strict';

Connector.useMediaSessionApi();
Connector.playerSelector = '#player';
