'use strict';

Connector.playerSelector = '.stream-block';

Connector.artistSelector = '.stream-content__title';

Connector.trackSelector = '.stream-content__artist';

Connector.pauseButtonSelector = '.stream-controls__btn-play.btn-pause';
