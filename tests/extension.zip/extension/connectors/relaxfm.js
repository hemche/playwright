'use strict';

Connector.playerSelector = '.main-player__wrapp';

Connector.artistSelector = '.TitleExecutorAir';

Connector.trackSelector = '.TitleTracksAir';

Connector.pauseButtonSelector = '.toggleplayer.stop';
