'use strict';

$(function() {
	$('a.help').click(() => {
		$('#description').show();
	});
});
